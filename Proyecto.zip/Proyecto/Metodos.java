package Proyecto;
import java.util.Scanner;
public class Metodos
{
    String equipos[];
    
    int j1, j2;
    
    int j3 = 0, j4 = 0, total2 = 0, total1=0;
    int j5 = 0, j6 = 0, total3 = 0;
   
    int a2=0, b2=0, c2=0;
    int a3=0, b3=0, c3=0;
    
 
    public Proyecto Ingreso()
    {
        Scanner aiuda = new Scanner(System.in);
        Proyecto p = new Proyecto();
        
            p.setEquipo1("Barcelona");
            p.setEquipo2("Clan Juvenil");
            p.setEquipo3("Delfin");
            
            p.setP_g(3); p.setP_e(1); p.setP_p(0);

            System.out.println("Los equipos clasificantes son:");
            System.out.println("Barcelona");
            System.out.println("Clan Juvenil");
            System.out.println("Delfin");
        
            System.out.println("");
            
            System.out.println("Ingrese los partidos ganados de Barcelona: ");     
            p.setA1(aiuda.nextInt());
            System.out.println("Ingrese los partidos empatados de Barcelona: ");     
            p.setB1(aiuda.nextInt());
            System.out.println("Ingrese los partidos perdidos de Barcelona: ");     
            p.setC1(aiuda.nextInt());
            
            System.out.println("");
            
            System.out.println("Ingrese los partidos ganados de Clan Juvenil: ");     
            p.setA2(aiuda.nextInt());
            System.out.println("Ingrese los partidos empatados de Clan Juvenil: ");     
            p.setB2(aiuda.nextInt());
            System.out.println("Ingrese los partidos perdidos de Clan Juvenil: ");     
            p.setC2(aiuda.nextInt());
            
            System.out.println("");
            
            System.out.println("Ingrese los partidos ganados de Delfin: ");     
            p.setA3(aiuda.nextInt()); 
            System.out.println("Ingrese los partidos empatados de Delfin: ");     
            p.setB3(aiuda.nextInt());
            System.out.println("Ingrese los partidos perdidos de Delfin: ");     
            p.setC3(aiuda.nextInt());
            
        return p;
    }
    
        public Proyecto[] Agregar()
        {
        Proyecto misEquipos[];
        misEquipos = new Proyecto[3];
        for (int i=0; i<misEquipos.length; i++)
            misEquipos[i]= Ingreso();
        return misEquipos;
        }
            
        public void Puntajes(Proyecto[] misEquipos, Proyecto p)
        {  
            for(int i=0; i<misEquipos.length; i++)
                
            System.out.println("Puntos de partidos ganados de "+p.getEquipo1()+": "+(p.getA1()*p.getP_g())+" pts.");       
            System.out.println("Puntos de partidos empatados de "+p.getEquipo1()+": "+((p.getB1()*p.getP_e()))+" pts.");
            
            System.out.println("");
            
            System.out.println("Puntos de partidos ganados de "+p.getEquipo2()+": "+(p.getA2()*p.getP_g())+" pts.");       
            System.out.println("Puntos de partidos empatados de "+p.getEquipo2()+": "+(p.getB2()*p.getP_e())+" pts.");
            
            System.out.println("");
            
            System.out.println("Puntos de partidos ganados de "+p.getEquipo3()+": "+(p.getA3()*p.getP_g())+" pts.");       
            System.out.println("Puntos de partidos empatados de "+p.getEquipo3()+": "+(p.getB3()*p.getP_e())+" pts.");
            
            System.out.println("");
            j1 = (p.getA1()*p.getP_g());
            j2 = (p.getB1()*p.getP_e());
            total1= j1+j2;
            
            j3 = (p.getA2()*p.getP_g());
            j4 = (p.getB2()*p.getP_e());
            total2 = j3+j4;
            
            j5 = (p.getA3()*p.getP_g());
            j6 = (p.getB3()*p.getP_e());
            total3 = j5+j6;
            
            System.out.println("La totalidad de puntos de "+p.getEquipo1()+" son "+total1+ " pts.");
            System.out.println("La totalidad de puntos de "+p.getEquipo2()+" son "+total2+ " pts.");
            System.out.println("La totalidad de puntos de "+p.getEquipo3()+" son "+total3+ " pts.");
        }
              
        public void Estadistica(Proyecto[] misEquipos, Proyecto p)
        {         
            String equipos[];
            equipos = new String[3];
            equipos[0] = "Barcelona";
            equipos[1] = "Clan Juvenil";
            equipos[2] = "Delfin"; 
            for (int i=0; i<misEquipos.length; i++)
            {
              
            System.out.println("Los partidos ganados de "+equipos[0]+": "+p.getA1());  
            System.out.println("Los partidos empatados de "+equipos[0]+": "+p.getB1());  
            System.out.println("Los partidos perdidos de "+equipos[0]+": "+p.getC1());  
              
            System.out.println("");
            
            System.out.println("Los partidos ganados de "+equipos[1]+": "+p.getA2());  
            System.out.println("Los partidos empatados de "+equipos[1]+": "+p.getB2());  
            System.out.println("Los partidos perdidos de "+equipos[1]+": "+p.getC2());
            
            System.out.println("");
            
            System.out.println("Los partidos ganados de "+equipos[2]+": "+p.getA3());  
            System.out.println("Los partidos empatados de "+equipos[2]+": "+p.getB3());  
            System.out.println("Los partidos perdidos de "+equipos[2]+": "+p.getC3());
            }
        }

        public void EquipoGanador(Proyecto[] misEquipos, Proyecto p)
        {           
            System.out.println(""); 
            System.out.println("-"+p.getEquipo1()+" "+total1+" pts.");
             
            System.out.println("-"+p.getEquipo2()+" "+total2+" pts.");
             
            System.out.println("-"+p.getEquipo3()+" "+total3+" pts.");
            System.out.println("");
             
            if (total1>total2 && total1>total3) 
            {
                System.out.println("BARCELONA ES EL CAMPEÓN");
                System.out.println("");
            }
            
            if (total2>total1 && total2>total3) 
            {
                System.out.println("CLAN JUVENIL ES EL CAMPEÓN");
                System.out.println("");
            }
		
            if (total3>total1 && total3>total2) 
            {		
                System.out.println("DELFÍN ES EL CAMPEÓN ");
                System.out.println("");
            }
		
            if (total1==total2 || total1==total3) 
            {
                System.out.println("Los equipos tendran que desempatar");
                System.out.println("");
            }
            
            if (total2==total3) 
            {
                System.out.println("Los equipos tendran que desempatar");
                System.out.println("");
            }
            
           
        }
    
        public void EquipoPerdedor(Proyecto[] misEquipos, Proyecto p)
        {
            System.out.println("");
            System.out.println("-"+p.getEquipo1()+" "+total1+" pts.");
            
            System.out.println("-"+p.getEquipo2()+" "+total2+" pts.");
            
            System.out.println("-"+p.getEquipo3()+" "+total3+" pts.");
            System.out.println("");
             
            if (total1<total2 && total1<total3) 
            {
                System.out.println("El equipo con menos puntaje fue Barcelona");
                System.out.println("");
            }
            
            if (total2<total1 && total2<total3) 
            {
                System.out.println("El equipo con menos puntaje fue Clan Juvenil");
                System.out.println("");
            }
		
            if (total3<total1 && total3<total2) 
            {		
                System.out.println("El equipo con menos puntaje fue Delfin");
                System.out.println("");
            }  
            
            if (total1==total2 || total1==total3) 
            {
                System.out.println("Los equipos tendran que desempatar");
                System.out.println("");
            }
            
            if (total2==total3) 
            {
                System.out.println("Los equipos tendran que desempatar");
                System.out.println("");
            }
            
        }
         
}

package Proyecto;

public class Proyecto
{
    private String equipo1;
    private String equipo2;
    private String equipo3;

    private int a1, b1, c1, total1;
    private int a2, b2, c2, total2;
    private int a3, b3, c3, total3;
    private int p_g, p_e, p_p;

    private int j1, j2;
    
    
    private int totala, totalb, totalc;
    /**
     * @return the equipo1
     */
    public String getEquipo1() {
        return equipo1;
    }

    /**
     * @param equipo1 the equipo1 to set
     */
    public void setEquipo1(String equipo1) {
        this.equipo1 = equipo1;
    }

    /**
     * @return the equipo2
     */
    public String getEquipo2() {
        return equipo2;
    }

    /**
     * @param equipo2 the equipo2 to set
     */
    public void setEquipo2(String equipo2) {
        this.equipo2 = equipo2;
    }

    /**
     * @return the equipo3
     */
    public String getEquipo3() {
        return equipo3;
    }

    /**
     * @param equipo3 the equipo3 to set
     */
    public void setEquipo3(String equipo3) {
        this.equipo3 = equipo3;
    }

    /**
     * @return the a1
     */
    public int getA1() {
        return a1;
    }

    /**
     * @param a1 the a1 to set
     */
    public void setA1(int a1) {
        this.a1 = a1;
    }

    /**
     * @return the b1
     */
    public int getB1() {
        return b1;
    }

    /**
     * @param b1 the b1 to set
     */
    public void setB1(int b1) {
        this.b1 = b1;
    }

    /**
     * @return the c1
     */
    public int getC1() {
        return c1;
    }

    /**
     * @param c1 the c1 to set
     */
    public void setC1(int c1) {
        this.c1 = c1;
    }

    /**
     * @return the p_g
     */
    public int getP_g() {
        return p_g;
    }

    /**
     * @param p_g the p_g to set
     */
    public void setP_g(int p_g) {
        this.p_g = p_g;
    }

    /**
     * @return the p_e
     */
    public int getP_e() {
        return p_e;
    }

    /**
     * @param p_e the p_e to set
     */
    public void setP_e(int p_e) {
        this.p_e = p_e;
    }

    /**
     * @return the p_p
     */
    public int getP_p() {
        return p_p;
    }

    /**
     * @param p_p the p_p to set
     */
    public void setP_p(int p_p) {
        this.p_p = p_p;
    }


    /**
     * @return the j1
     */
    public int getJ1() {
        return j1;
    }

    /**
     * @param j1 the j1 to set
     */
    public void setJ1(int j1) {
        this.j1 = j1;
    }

    /**
     * @return the j2
     */
    public int getJ2() {
        return j2;
    }

    /**
     * @param j2 the j2 to set
     */
    public void setJ2(int j2) {
        this.j2 = j2;
    }

    

    /**
     * @return the a2
     */
    public int getA2() {
        return a2;
    }

    /**
     * @param a2 the a2 to set
     */
    public void setA2(int a2) {
        this.a2 = a2;
    }

    /**
     * @return the b2
     */
    public int getB2() {
        return b2;
    }

    /**
     * @param b2 the b2 to set
     */
    public void setB2(int b2) {
        this.b2 = b2;
    }

    /**
     * @return the c2
     */
    public int getC2() {
        return c2;
    }

    /**
     * @param c2 the c2 to set
     */
    public void setC2(int c2) {
        this.c2 = c2;
    }

    /**
     * @return the a3
     */
    public int getA3() {
        return a3;
    }

    /**
     * @param a3 the a3 to set
     */
    public void setA3(int a3) {
        this.a3 = a3;
    }

    /**
     * @return the b3
     */
    public int getB3() {
        return b3;
    }

    /**
     * @param b3 the b3 to set
     */
    public void setB3(int b3) {
        this.b3 = b3;
    }

    /**
     * @return the c3
     */
    public int getC3() {
        return c3;
    }

    /**
     * @param c3 the c3 to set
     */
    public void setC3(int c3) {
        this.c3 = c3;
    }

    /**
     * @return the totala
     */
    public int getTotala() {
        return totala;
    }

    /**
     * @param totala the totala to set
     */
    public void setTotala(int totala) {
        this.totala = totala;
    }

    /**
     * @return the totalb
     */
    public int getTotalb() {
        return totalb;
    }

    /**
     * @param totalb the totalb to set
     */
    public void setTotalb(int totalb) {
        this.totalb = totalb;
    }

    /**
     * @return the totalc
     */
    public int getTotalc() {
        return totalc;
    }

    /**
     * @param totalc the totalc to set
     */
    public void setTotalc(int totalc) {
        this.totalc = totalc;
    }

    /**
     * @return the total1
     */
    public int getTotal1() {
        return total1;
    }

    /**
     * @param total1 the total1 to set
     */
    public void setTotal1(int total1) {
        this.total1 = total1;
    }

    /**
     * @return the total2
     */
    public int getTotal2() {
        return total2;
    }

    /**
     * @param total2 the total2 to set
     */
    public void setTotal2(int total2) {
        this.total2 = total2;
    }

    /**
     * @return the total3
     */
    public int getTotal3() {
        return total3;
    }

    /**
     * @param total3 the total3 to set
     */
    public void setTotal3(int total3) {
        this.total3 = total3;
    }
    
    
    
    
    
    
}
package Proyecto;
import java.util.Scanner;

public class Principal
{
    public static void main(String[] args)
    {
        Scanner aiuda2 = new Scanner(System.in);
        Proyecto[] p2 = new Proyecto[1];
        Metodos m = new Metodos();
        Proyecto pro  = m.Ingreso(); 
        String equipos[] = null;
        String regresar = "";
        int op=0;    
        while(!"Si".equals(regresar))
        {    	
        System.out.println("");
        System.out.println("Ingrese una opcion");
        System.out.println("1. Puntajes ");
        System.out.println("2. Estadisticas");
        System.out.println("3. Equipo ganador");
        System.out.println("4. Equipo con menos puntaje");
        System.out.println("5. Salir");
        op = aiuda2.nextInt();
            switch(op)
            {
                case 1:
                    m.Puntajes(p2, pro);
                    System.out.println("¿Desea salir del programa?");
                    System.out.println("Si o No");
                    regresar = aiuda2.next();
                    if (regresar == "No")
                    {
                        op = aiuda2.nextInt();
                    }
                    break;
                case 2:
                    m.Estadistica(p2, pro);
                    System.out.println("¿Desea salir del programa?");
                    System.out.println("Si o No");
                    regresar = aiuda2.next();
                    if (regresar == "No")
                    {
                        op = aiuda2.nextInt();
                    }
                break;
                case 3:
                    m.EquipoGanador(p2, pro);              
                    System.out.println("¿Desea salir del programa?");
                    System.out.println("Si o No");
                    regresar = aiuda2.next();
                    if (regresar == "No")
                    {
                        op = aiuda2.nextInt();
                    }
                break;
                case 4:
                    m.EquipoPerdedor(p2, pro);
                    System.out.println("¿Desea salir del programa?");
                    System.out.println("Si o No");
                    regresar = aiuda2.next();
                    if (regresar == "No")
                    {
                        op = aiuda2.nextInt();
                    }
                break;
            
                case 5:
                    System.out.println("¿Desea salir del programa?");
                    System.out.println("Si o No");
                    regresar = aiuda2.next();
                    if (regresar == "No")
                    {
                        op = aiuda2.nextInt();
                    }
                    if(regresar =="Si")
                    {
                        System.out.println("Gracias por usar el programa :v");    
                        break;
                    }
            }
            
        }
    
    
    }
    
}
